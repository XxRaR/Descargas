import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from PIL import Image
"""Definimos las funciones para cargar textura dibujar y la principal"""

def load_texture(filename):
    img = Image.open(filename)
    img = img.transpose(Image.FLIP_TOP_BOTTOM)
    img_data = img.convert("RGB").tobytes()
    width, height = img.size

    texture_id = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    return texture_id


def init_lighting():
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)

    glLightfv(GL_LIGHT0, GL_POSITION, (-5, 5, 5, 1))
    glLightfv(GL_LIGHT0, GL_DIFFUSE, (1.0, 1.0, 0.8, 1.0))
    glLightfv(GL_LIGHT1, GL_POSITION, (5, 5, 5, 1))
    glLightfv(GL_LIGHT1, GL_DIFFUSE, (0.8, 0.8, 1.0, 1.0))

    glEnable(GL_COLOR_MATERIAL)
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
    glMaterialfv(GL_FRONT, GL_SPECULAR, (1.0, 1.0, 1.0, 1.0))
    glMateriali(GL_FRONT, GL_SHININESS, 100)


def draw_textured_cube(w, h, d):
    glBegin(GL_QUADS)
    #Cara trasera
    glTexCoord2f(1, 0); glVertex3f(w, -h, -d)
    glTexCoord2f(1, 1); glVertex3f(w, h, -d)
    glTexCoord2f(0, 1); glVertex3f(-w, h, -d)
    glTexCoord2f(0, 0); glVertex3f(-w, -h, -d)
    #Cara delantera
    glTexCoord2f(0, 0); glVertex3f(-w, -h, d)
    glTexCoord2f(0, 1); glVertex3f(-w, h, d)
    glTexCoord2f(1, 1); glVertex3f(w, h, d)
    glTexCoord2f(1, 0); glVertex3f(w, -h, d)
    #Superior
    glTexCoord2f(0, 1); glVertex3f(-w, h, d)
    glTexCoord2f(0, 0); glVertex3f(-w, h, -d)
    glTexCoord2f(1, 0); glVertex3f(w, h, -d)
    glTexCoord2f(1, 1); glVertex3f(w, h, d)
    #Inferior
    glTexCoord2f(1, 1); glVertex3f(w, -h, d)
    glTexCoord2f(1, 0); glVertex3f(w, -h, -d)
    glTexCoord2f(0, 0); glVertex3f(-w, -h, -d)
    glTexCoord2f(0, 1); glVertex3f(-w, -h, d)
    #Derecha
    glTexCoord2f(1, 0); glVertex3f(w, -h, -d)
    glTexCoord2f(0, 0); glVertex3f(w, -h, d)
    glTexCoord2f(0, 1); glVertex3f(w, h, d)
    glTexCoord2f(1, 1); glVertex3f(w, h, -d)
    """Izquierda"""
    glTexCoord2f(0, 0); glVertex3f(-w, -h, d)
    glTexCoord2f(1, 0); glVertex3f(-w, -h, -d)
    glTexCoord2f(1, 1); glVertex3f(-w, h, -d)
    glTexCoord2f(0, 1); glVertex3f(-w, h, d)
    glEnd()

"""Se dibuja la capa"""
def draw_cape():
    """Dibuja una capa roja"""
    glDisable(GL_TEXTURE_2D)
    glBegin(GL_QUADS)

    #Parte superior, rojo brillante
    glColor3f(1.0, 0.0, 0.0)
    glVertex3f(-1.5, 1.5, -0.6)
    glVertex3f(1.5, 1.5, -0.6)

    #Parte inferior, rojo oscuro 
    glColor3f(0.3, 0.0, 0.0)
    glVertex3f(2.0, -2.0, -1.0)
    glVertex3f(-2.0, -2.0, -1.0)

    glEnd()
    glEnable(GL_TEXTURE_2D)

"""Dibuja el robot"""
def draw_robot(texture_id):
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glColor3f(1, 1, 1)
    quad = gluNewQuadric()

    #Capa con degradado
    draw_cape()

    #Cuerpo
    glPushMatrix()
    draw_textured_cube(1, 1.5, 0.5)
    glPopMatrix()

    #Cabeza
    glPushMatrix()
    glTranslatef(0, 2.2, 0)
    draw_textured_cube(0.6, 0.6, 0.6)
    glPopMatrix()

    #Ojos verdes
    glPushMatrix()
    glTranslatef(0, 2.2, 0.55)
    for x in [-0.25, 0.25]:
        glPushMatrix()
        glTranslatef(x, 0.1, 0)
        glColor3f(0.0, 1.0, 0.0)
        gluSphere(quad, 0.1, 16, 16)
        glPopMatrix()
    glPopMatrix()

    #Antenas
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glColor3f(1, 1, 1)
    for x in [-0.25, 0.25]:
        glPushMatrix()
        glTranslatef(x, 2.9, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(quad, 0.05, 0.03, 0.8, 12, 12)
        glPopMatrix()

        #bolita azul brillante
        glPushMatrix()
        glColor3f(0.1, 0.6, 1.0)
        glTranslatef(x, 3.7, 0)
        gluSphere(quad, 0.12, 16, 16)
        glPopMatrix()

    #Brazos
    glBindTexture(GL_TEXTURE_2D, texture_id)
    for x in [-1.6, 1.6]:
        glPushMatrix()
        glTranslatef(x, 0.5, 0)
        draw_textured_cube(0.3, 1.0, 0.3)
        glPopMatrix()

    #Piernas
    for x in [-0.5, 0.5]:
        glPushMatrix()
        glTranslatef(x, -2.0, 0)
        draw_textured_cube(0.4, 1.0, 0.4)
        glPopMatrix()


def draw_lamps():
    quad = gluNewQuadric()
    glColor3f(1.0, 1.0, 0.0)
    glPushMatrix()
    glTranslatef(-5, 5, 5)
    gluSphere(quad, 0.3, 16, 16)
    glPopMatrix()

    glColor3f(0.8, 0.8, 1.0)
    glPushMatrix()
    glTranslatef(5, 5, 5)
    gluSphere(quad, 0.3, 16, 16)
    glPopMatrix()


def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Robot metálico con capa")

    glEnable(GL_DEPTH_TEST)
    glEnable(GL_TEXTURE_2D)
    gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
    glTranslatef(0.0, -1.0, -15)

    init_lighting()

    """Cargamos la imagen como textura"""

    texture_id = load_texture("C:\\Users\\Usuario\\Desktop\\metal.jpg")
    clock = pygame.time.Clock()
    angle = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glPushMatrix()
        glRotatef(angle, 0, 1, 0)

        draw_robot(texture_id)
        draw_lamps()

        glPopMatrix()
        pygame.display.flip()
        clock.tick(60)
        angle += 0.5


if __name__ == "__main__":
    main()
